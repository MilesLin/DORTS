﻿namespace WindowsFormsApp1.Model
{
    public enum Sex
    {
        男,
        女
    }
}